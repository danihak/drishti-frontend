"use client";

import { Suspense, type ComponentType } from "react";
import { useSearchParams } from "next/navigation";

/**
 * Role and estimator, read from the live query string.
 *
 * An earlier version read `window.location.search` inside a mount effect to
 * keep the shell server-renderable. That was wrong: client-side navigation does
 * not remount the layout, so the effect never re-fired and the role froze at
 * its default while the URL said otherwise — the switcher appeared to do
 * nothing.
 *
 * `useSearchParams` is the correct API and it stays in sync. The cost is that a
 * component using it renders its Suspense fallback on the server. For a screen
 * whose every number arrives from a fetch, the server had nothing to render
 * anyway — so this trade is the right way round.
 */
export function useRole(): string {
  return useSearchParams().get("role") ?? "lender";
}

export function useEstimator(): string {
  return useSearchParams().get("est") ?? "fusion";
}

/**
 * Carry the role through every internal link.
 *
 * Hardcoded hrefs dropped ?role=, so opening a farm from the claims view
 * silently returned the user to the credit officer. One helper rather than four
 * call sites, so the next link added cannot reintroduce it.
 */
export function useRoleLink() {
  const role = useRole();
  return (href: string) =>
    !role || role === "lender"
      ? href
      : `${href}${href.includes("?") ? "&" : "?"}role=${role}`;
}

/** Suspense boundary, applied by the helper rather than remembered per page. */
export function withParams<P extends object>(Inner: ComponentType<P>) {
  return function Wrapped(props: P) {
    return (
      <Suspense fallback={<p className="loading">Loading…</p>}>
        <Inner {...props} />
      </Suspense>
    );
  };
}
