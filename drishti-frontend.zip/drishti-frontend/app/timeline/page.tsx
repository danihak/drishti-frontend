"use client";

import { useEffect, useState } from "react";
import { StatePill } from "@/components/Strip";
import { getObservations, getPortfolio, shortDate } from "@/lib/api";

/**
 * CLAIMS ASSESSOR — "what happened on this field, and when?"
 *
 * Not a dashboard. A chronology, and a defensible one. An assessor disputing a
 * loss six months from now needs every observation in order, each with the
 * sensor that produced it, the cloud state, the rung used and the rule version
 * that scored it — and nothing else.
 *
 * What is deliberately absent: yield, exposure, any verdict. An assessor who is
 * shown a conclusion is an assessor who has been led. The record is the product
 * here; the judgement is theirs.
 */
export default function Timeline() {
  const [farms, setFarms] = useState<any[]>([]);
  const [sel, setSel] = useState("");
  const [obs, setObs] = useState<any[] | null>(null);

  useEffect(() => {
    getPortfolio().then((p) => {
      setFarms(p.rows);
      if (p.rows.length) setSel(p.rows[0].farm_id);
    }).catch(() => setFarms([]));
  }, []);

  useEffect(() => {
    if (!sel) return;
    setObs(null);
    getObservations(sel).then(setObs).catch(() => setObs([]));
  }, [sel]);

  const farm = farms.find((f) => f.farm_id === sel);
  const counts = (obs ?? []).reduce((a: Record<string, number>, o) => {
    a[o.state] = (a[o.state] ?? 0) + 1; return a;
  }, {});

  return (
    <div style={{ paddingTop: 22 }}>
      <h1 style={{ fontSize: 22, fontWeight: 600, margin: "0 0 6px" }}>
        Loss chronology
      </h1>
      <p className="note">
        Every observation in order, with the sensor that produced it and the rule
        version that scored it. No yield, no exposure, no verdict — an assessor
        who is shown a conclusion has been led. The record is the deliverable.
      </p>

      <div style={{ display: "flex", gap: 14, alignItems: "center",
                    marginTop: 16, flexWrap: "wrap" }}>
        <div className="rolepill">
          <span>field</span>
          <select value={sel} onChange={(e) => setSel(e.target.value)}>
            {farms.map((f) => (
              <option key={f.farm_id} value={f.farm_id}>{f.farm_name}</option>
            ))}
          </select>
        </div>
        {obs && (
          <span className="note">
            {obs.length} observations · {counts.Verified ?? 0} measured ·{" "}
            {counts.Degraded ?? 0} estimated · {counts.Blind ?? 0} not observed
          </span>
        )}
        <span className="spacer" />
        <button>Export the pack</button>
      </div>

      {!obs ? <p className="loading">Reading the record…</p> : (
        <div style={{ marginTop: 20 }}>
          {obs.slice().reverse().map((o, i) => (
            <div key={i} style={{
              display: "grid", gridTemplateColumns: "92px 20px 1fr",
              gap: 14, alignItems: "start",
              padding: "12px 0", borderBottom: "1px solid var(--hairline)",
            }}>
              <div style={{ textAlign: "right" }}>
                <div style={{ font: "600 13px Inter" }}>{shortDate(o.obs_date)}</div>
                <div className="note" style={{ fontSize: 11 }}>day {o.das}</div>
              </div>

              {/* The spine. A break in it is an unobserved stretch, and that is
                  the thing a claim most often turns on. */}
              <div style={{ position: "relative", height: "100%" }}>
                <i style={{ position: "absolute", left: 9, top: 0, bottom: -12,
                            width: 1, background: "var(--rule)", display: "block" }} />
                <i style={{
                  position: "absolute", left: 5, top: 5, width: 9, height: 9,
                  borderRadius: "50%", display: "block",
                  background: o.state === "Verified" ? "var(--measured)"
                            : o.state === "Degraded" ? "var(--estimated)" : "#fff",
                  border: o.state === "Blind"
                    ? "1px dashed var(--ink-ghost)" : "none",
                }} />
              </div>

              <div>
                <div style={{ display: "flex", gap: 10, alignItems: "center",
                              flexWrap: "wrap" }}>
                  <StatePill state={o.state} />
                  <span className="note" style={{ fontSize: 12 }}>
                    {o.stage?.replace("_", " ")} · {o.cloudy ? "cloudy" : "clear"} ·{" "}
                    {Math.round((o.valid_pixel_fraction ?? 0) * 100)}% usable pixels
                  </span>
                </div>
                <div className="note" style={{ marginTop: 5 }}>
                  <span className="mono">{o.rung_label}</span>
                  {o.ndvi != null && <> · NDVI {o.ndvi.toFixed(3)}</>}
                  {o.ndvi_uncertainty != null && <> ±{o.ndvi_uncertainty.toFixed(3)}</>}
                  {" · "}<span className="mono">{o.rule_version}</span>
                </div>
                {o.reason && (
                  <div className="note" style={{ marginTop: 4, fontSize: 11.5 }}>
                    {o.reason}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <p className="note" style={{ marginTop: 18 }}>
        A hollow dashed marker is a pass that produced no usable reading. Those
        are not omissions — they are recorded, dated, and are usually what a
        disputed claim turns on.
      </p>
    </div>
  );
}
