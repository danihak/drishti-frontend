"use client";

/**
 * Confidence mix, weighted by area rather than farm count.
 *
 * A hundred small unseen plots and one large unseen plot are different
 * problems, and a count-weighted bar hides that.
 *
 * The unseen share is drawn as a dotted rule rather than a block, for the same
 * reason the strip leaves it blank: absence should look like absence.
 */
export function Mix({ mix }: { mix: Record<string, number> }) {
  const m = mix.Verified ?? 0;
  const e = mix.Degraded ?? 0;
  const u = mix.Blind ?? 0;
  const p = (x: number) => `${Math.round(x * 100)}%`;

  return (
    <div style={{ flex: 1, minWidth: 280 }}>
      <div className="mix">
        {m > 0 && <div className="m" style={{ width: `${m * 100}%` }} />}
        {e > 0 && <div className="e" style={{ width: `${e * 100}%` }} />}
        {u > 0 && <div className="u" style={{ width: `${u * 100}%`,
                                              alignSelf: "flex-end" }} />}
      </div>
      <div className="mixkey">
        <div><b className="m">{p(m)}</b><span>measured</span></div>
        <div><b className="e">{p(e)}</b><span>estimated</span></div>
        <div><b>{p(u)}</b><span>not seen</span></div>
      </div>
    </div>
  );
}
