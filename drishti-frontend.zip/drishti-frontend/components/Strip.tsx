"use client";

import { StripObservation } from "@/lib/api";

/**
 * The season strip. Two encodings in one component.
 *
 *   BAR HEIGHT   the NDVI value on that pass
 *   TICK COLOUR  the confidence state, on a 3px row below the baseline
 *
 * Separating them matters. A tall bar and a trustworthy bar are different
 * claims, and a single visual channel forces you to choose which one to show.
 * Height carries the measurement; the tick carries how much to believe it.
 *
 * Blind is the absence of a bar AND the absence of a tick. Not grey — nothing.
 * A grey mark says "poor reading here"; nothing says "no reading here", and
 * that distinction is the product.
 *
 * Monsoon windows are shaded behind the bars, because the whole finding is that
 * the ink disappears inside them.
 */

const FILL = {
  measured: "#0E6B5C",
  estimated: "repeating-linear-gradient(45deg,#C17A1F 0 2px,transparent 2px 4px)",
  unseen: "transparent",
} as const;

const TICK = {
  measured: "#0E6B5C",
  estimated: "#C17A1F",
  unseen: "transparent",
} as const;

function monsoonBands(obs: StripObservation[]) {
  const bands: { left: number; width: number }[] = [];
  let start: number | null = null;
  obs.forEach((o, i) => {
    const inK = o.season === "kharif";
    if (inK && start === null) start = i;
    if (!inK && start !== null) {
      bands.push({ left: (start / obs.length) * 100,
                   width: ((i - start) / obs.length) * 100 });
      start = null;
    }
  });
  if (start !== null) {
    bands.push({ left: (start / obs.length) * 100,
                 width: ((obs.length - start) / obs.length) * 100 });
  }
  return bands;
}

export function Strip({
  observations, height = 40, onHover,
}: {
  observations: StripObservation[];
  height?: number;
  onHover?: (o: StripObservation | null) => void;
}) {
  if (!observations.length) {
    return <div style={{ position: "relative", height }}>
      <i style={{ position: "absolute", left: 0, right: 0, top: height * 0.75,
                  height: 1, background: "var(--rule)", display: "block" }} />
    </div>;
  }

  const barZone = Math.round(height * 0.75);
  const bands = monsoonBands(observations);

  return (
    <div style={{ position: "relative", height }}
         onMouseLeave={() => onHover?.(null)}>

      {/* The monsoon, shaded. Where the ink disappears. */}
      {bands.map((b, i) => (
        <i key={`b${i}`} style={{
          position: "absolute", top: 0, bottom: 6,
          left: `${b.left}%`, width: `${b.width}%`,
          background: "var(--panel-alt)", display: "block",
        }} />
      ))}

      {/* NDVI as bar height. */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 0,
                    display: "flex", alignItems: "flex-end", height: barZone }}>
        {observations.map((o, i) => (
          <i key={`s${i}`}
             onMouseEnter={() => onHover?.(o)}
             title={`${o.date} · ${o.state}` +
               (o.ndvi != null ? ` · NDVI ${o.ndvi.toFixed(3)}` : "") +
               ` · ${Math.round(o.valid_pixel_fraction * 100)}% clear`}
             style={{
               flex: 1, alignSelf: "flex-end",
               height: `${o.ndvi != null ? Math.max(6, o.ndvi * 100) : 0}%`,
               background: FILL[o.state], backgroundClip: "content-box",
               padding: "0 0.5px", display: "block", minHeight: 0,
             }} />
        ))}
      </div>

      {/* The baseline. Runs the full width, so a gap reads as a gap. */}
      <i style={{ position: "absolute", left: 0, right: 0, top: barZone,
                  height: 1, background: "var(--rule)", display: "block" }} />

      {/* Confidence, as its own row. Independent of the value above it. */}
      <div style={{ position: "absolute", left: 0, right: 0, top: barZone + 2,
                    display: "flex", height: 3 }}>
        {observations.map((o, i) => (
          <i key={`t${i}`} style={{
            flex: 1, height: 3, background: TICK[o.state],
            backgroundClip: "content-box", padding: "0 0.5px", display: "block",
          }} />
        ))}
      </div>
    </div>
  );
}

/** Season markers, positioned along the axis. */
export function StripAxis({ observations }: { observations: StripObservation[] }) {
  if (!observations.length) return null;

  const marks: { left: number; label: string }[] = [];
  let seen = "";
  observations.forEach((o, i) => {
    const key = `${o.date.slice(0, 4)}-${o.season}`;
    if (o.season === "kharif" && key !== seen) {
      marks.push({ left: (i / observations.length) * 100,
                   label: `${o.date.slice(0, 4)} Kharif` });
      seen = key;
    }
  });

  return (
    <div style={{ position: "relative", height: 16, marginTop: 2 }}>
      {marks.map((m, i) => (
        <span key={i} style={{
          position: "absolute", bottom: 0, left: `${m.left}%`,
          font: "500 10px/1 Inter", letterSpacing: ".08em",
          textTransform: "uppercase", color: "var(--ink-soft)",
          whiteSpace: "nowrap",
        }}>{m.label}</span>
      ))}
    </div>
  );
}

/** State as a bordered pill, in the mono face used for machine values. */
export function StatePill({ state }: { state: string }) {
  const map: Record<string, [string, string, string]> = {
    Verified:  ["#0E6B5C", "#0E6B5C33", "#0E6B5C0D"],
    Degraded:  ["#8A4A00", "#C17A1F55", "#C17A1F0D"],
    Blind:     ["#5F6864", "#D8D5CE", "#F6F4F0"],
  };
  const [fg, border, bg] = map[state] ?? map.Blind;
  return (
    <span style={{
      font: "500 10px/1 'JetBrains Mono',monospace", letterSpacing: ".06em",
      color: fg, border: `1px solid ${border}`, background: bg,
      borderRadius: 4, padding: "4px 6px", width: "max-content",
      display: "inline-block",
    }}>
      {state === "Blind" ? "NOT SEEN" : state.toUpperCase()}
    </span>
  );
}
