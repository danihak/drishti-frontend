import "./globals.css";
import type { Metadata } from "next";
import { Suspense } from "react";
import { Chrome } from "@/components/Chrome";
import { Provenance } from "@/components/Provenance";

export const metadata: Metadata = {
  title: "DRISHTI+",
  description: "Crop intelligence with the confidence stated on every number",
};

/**
 * `suppressHydrationWarning` on <html> only.
 *
 * Browser extensions write attributes onto <html> before React hydrates and
 * React reports that as a mismatch. It is not our markup. Suppressing it at the
 * root is far narrower than silencing the warning on components that render
 * real data, where a genuine mismatch would matter.
 */
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" />
      </head>
      <body>
        <Suspense fallback={null}><Chrome /></Suspense>
        <div className="shell">{children}</div>
        <Provenance />
      </body>
    </html>
  );
}
