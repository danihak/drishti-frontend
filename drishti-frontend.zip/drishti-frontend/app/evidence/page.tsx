"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { getObservations, getPortfolio, shortDate } from "@/lib/api";

/**
 * Evidence — the audit screen.
 *
 * Every observation for a farm, append-only: date, stage, sensor, valid pixel
 * share, cloud state, rung used, resulting state, rule version.
 *
 * This is also the ClaimChronos data source. Same rows, different rendering:
 * an insurer disputing a loss six months later needs exactly this and nothing
 * more.
 */
export default function Evidence() {
  const [farms, setFarms] = useState<any[]>([]);
  const [sel, setSel] = useState<string>("");
  const [obs, setObs] = useState<any[] | null>(null);

  useEffect(() => {
    getPortfolio().then((p) => {
      setFarms(p.rows);
      if (p.rows.length) setSel(p.rows[0].farm_id);
    }).catch(() => setFarms([]));
  }, []);

  useEffect(() => {
    if (!sel) return;
    setObs(null);
    getObservations(sel).then(setObs).catch(() => setObs([]));
  }, [sel]);

  return (
    <div style={{ paddingTop: 22 }}>
      <h1 style={{ fontSize: 22, fontWeight: 600, margin: "0 0 6px" }}>
        Observation record
      </h1>
      <p className="note">
        Append-only. Every pass, whether it produced a number or not, with the
        rule version that scored it. A number that changes six months from now
        can be traced to the observation and the rule that produced it.
      </p>

      <div className="rolepill" style={{ marginTop: 16, width: "fit-content" }}>
        <span>farm</span>
        <select value={sel} onChange={(e) => setSel(e.target.value)}>
          {farms.map((f) => (
            <option key={f.farm_id} value={f.farm_id}>{f.farm_name}</option>
          ))}
        </select>
      </div>

      {!obs ? <p className="loading">Reading the record…</p> : (
        <table className="data" style={{ marginTop: 18 }}>
          <thead>
            <tr>
              <th>Date</th><th>Day</th><th>Stage</th><th>Clear px</th>
              <th>Cloud</th><th>Source</th><th>NDVI</th><th>Band</th>
              <th>State</th><th>Rule</th>
            </tr>
          </thead>
          <tbody>
            {obs.map((o, i) => (
              <tr key={i}>
                <td>{shortDate(o.obs_date)}</td>
                <td>{o.das}</td>
                <td>{o.stage?.replace("_", " ")}</td>
                <td>{Math.round((o.valid_pixel_fraction ?? 0) * 100)}%</td>
                <td>{o.cloudy ? "cloudy" : "clear"}</td>
                <td className="mono" style={{ fontSize: 10 }}>{o.rung_label}</td>
                <td>{o.ndvi == null ? "—" : o.ndvi.toFixed(3)}</td>
                <td>{o.ndvi_uncertainty == null ? "—"
                      : `±${o.ndvi_uncertainty.toFixed(3)}`}</td>
                <td><span className={`state ${o.state}`}>{o.state}</span></td>
                <td className="mono" style={{ fontSize: 10 }}>{o.rule_version}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
