"use client";

/**
 * The finding that justifies the entire architecture, given its own card.
 *
 * Measured over two years on these six farms: the satellite sees them several
 * times better in Rabi than in Kharif. Rabi is irrigated and stable — nothing
 * is at risk. Kharif is rainfed, the loan is outstanding, and the crop can fail.
 *
 * It sits in a hard-bordered card rather than in prose because it is the single
 * number a reader should leave with.
 */
export function SeasonRatio({ kharif, rabi }: { kharif: number; rabi: number }) {
  const ratio = kharif > 0 ? (rabi / kharif).toFixed(1) : "—";
  return (
    <div style={{
      display: "flex", gap: 28, alignItems: "center", padding: "18px 20px",
      margin: "18px 0 0", border: "1px solid var(--ink)", borderRadius: 4,
      background: "#fff", flexWrap: "wrap",
    }}>
      <div style={{ display: "flex", alignItems: "baseline", gap: 6, flex: "none" }}>
        <span style={{ font: "600 32px/1 Inter", letterSpacing: "-.02em" }}>
          {ratio}×
        </span>
        <span style={{
          font: "500 11px/1.3 Inter", letterSpacing: ".06em",
          textTransform: "uppercase", color: "var(--ink-soft)", maxWidth: 86,
        }}>better in the safe season</span>
      </div>
      <div style={{ display: "flex", gap: 24, flex: "none" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          <span style={{ font: "600 18px/1 Inter", color: "var(--estimated)" }}>
            {Math.round(kharif * 100)}%
          </span>
          <span style={{ font: "500 10px/1.2 'JetBrains Mono',monospace",
                         letterSpacing: ".06em", color: "var(--ink-soft)" }}>
            KHARIF PASSES CLEAR
          </span>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          <span style={{ font: "600 18px/1 Inter", color: "var(--measured)" }}>
            {Math.round(rabi * 100)}%
          </span>
          <span style={{ font: "500 10px/1.2 'JetBrains Mono',monospace",
                         letterSpacing: ".06em", color: "var(--ink-soft)" }}>
            RABI PASSES CLEAR
          </span>
        </div>
      </div>
      <p className="note" style={{ flex: 1, minWidth: 260, margin: 0 }}>
        Rabi is irrigated and stable. Kharif is when the crop is rainfed, the
        loan is outstanding, and the field can fail — and it is the season the
        satellite can barely see.
      </p>
    </div>
  );
}
