"use client";

import { useEffect, useState } from "react";
import { Explain as ExplainT, explain, getTools, shortDate } from "@/lib/api";

const AUDIENCES = ["lender", "farmer", "insurer", "exporter"] as const;

/**
 * The explanation panel, which shows its own working.
 *
 * Four regions, and the last two are the differentiator:
 *
 *   the answer            prose, framed for this audience
 *   the evidence chain    every link, back to its observation
 *   the tool trace        five functions, the called ones marked
 *   verification          whether a model wrote this, or the fallback did
 *
 * Competitors ship a chat bubble. The interesting part is not that a model
 * answered — it is being able to see exactly what it was allowed to read, and
 * what happened when it tried to say something the evidence did not support.
 */
export function ExplainPanel({ farmId }: { farmId: string }) {
  const [audience, setAudience] = useState<string>("lender");
  const [res, setRes] = useState<ExplainT | null>(null);
  const [tools, setTools] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [question, setQuestion] = useState("");

  useEffect(() => {
    getTools().then((t) => setTools((t.tools ?? []).map((x: any) => x.name)))
              .catch(() => setTools([]));
  }, []);

  async function ask(q?: string) {
    setBusy(true);
    try { setRes(await explain(farmId, audience, q || undefined)); }
    catch (e: any) {
      setRes({ answer: `The explanation service did not respond (${e.message}).`,
               refused: false, evidence_chain: [], guardrails_applied: [],
               generator: "error", farm_id: farmId, audience,
               confidence_state: "Blind", escalated: false,
               rule_version: "" } as ExplainT);
    }
    setBusy(false);
  }

  // Which tools were called is not returned per answer, so it is inferred from
  // the evidence chain rather than asserted. Guessing would be worse than
  // showing nothing.
  const called = new Set<string>();
  if (res && !res.refused) {
    called.add("get_farm_context");
    if (res.evidence_chain.length) called.add("get_latest_observation");
    if (res.evidence_chain.length > 1) called.add("get_observation_history");
    if (res.evidence_chain.some((l) => l.cloud_state)) called.add("get_cloud_state");
  }

  return (
    <div>
      <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
        <button className="primary" onClick={() => ask()} disabled={busy}>
          {busy ? "Asking…" : "Why is this flagged"}
        </button>
        {/* Same farm, same evidence, four renderings. Jital's five-users
            problem, demonstrated in one control. */}
        <div className="rolepill">
          <span>as</span>
          <select value={audience} onChange={(e) => setAudience(e.target.value)}>
            {AUDIENCES.map((a) => <option key={a} value={a}>{a}</option>)}
          </select>
        </div>
        <input
          value={question} onChange={(e) => setQuestion(e.target.value)}
          placeholder="or ask something — try: what should I use for stem borer"
          style={{ flex: 1, minWidth: 260, padding: "7px 10px", fontSize: 13,
                   border: "1px solid var(--rule)", borderRadius: 4,
                   font: "inherit" }}
          onKeyDown={(e) => { if (e.key === "Enter") ask(question); }} />
        <button onClick={() => ask(question)} disabled={busy || !question}>Ask</button>
      </div>

      {res && (
        <div style={{ marginTop: 18 }}>
          {res.refused ? (
            <div className="verify fallback">
              <p style={{ margin: "0 0 8px", fontSize: 14 }}>{res.answer}</p>
              <p className="note" style={{ margin: 0 }}>
                Refused before the model was called. This is a code path, not
                prompt text — the question never reached a language model.
              </p>
              <div className="guardrails">
                {res.guardrails_applied.map((g) => <code key={g}>{g}</code>)}
              </div>
              {res.escalated && (
                <p className="note" style={{ margin: "8px 0 0" }}>
                  Escalated to <b>{res.escalation_target}</b>.
                </p>
              )}
            </div>
          ) : (
            <>
              <p style={{ fontSize: 14.5, lineHeight: 1.6,
                          maxWidth: "var(--measure)" }}>{res.answer}</p>

              <h3 style={{ fontSize: 11, letterSpacing: ".07em",
                           textTransform: "uppercase", color: "var(--ink-soft)",
                           margin: "20px 0 8px" }}>Evidence</h3>
              <ul className="evidence">
                {res.evidence_chain.map((l, i) => (
                  <li key={i}>
                    <b>{l.index}</b> · {shortDate(l.obs_date)}
                    {l.das != null && ` · day ${l.das}`}
                    {" · "}<span className={`state ${l.state}`}>{l.state}</span>
                    {l.value != null && ` · ${l.value.toFixed(3)}`}
                    {l.uncertainty != null && ` ±${l.uncertainty.toFixed(3)}`}
                    {l.source && <> · <span className="mono">{l.source}</span></>}
                    {/* A Blind observation carries the estimate that was
                        REFUSED for being too wide. That rejection is the
                        evidence for the Blind state, and an institution asking
                        later why a field showed no number deserves to see it. */}
                    {l.rejected?.uncertainty != null && (
                      <div className="note" style={{ marginTop: 4 }}>
                        An estimate of ±{l.rejected.uncertainty.toFixed(2)} was
                        produced and refused against a ceiling of{" "}
                        {l.rejected.ceiling?.toFixed(2)}. Recorded as the reason
                        for Blind, not as a value.
                      </div>
                    )}
                    {l.note && <div className="note" style={{ marginTop: 4 }}>{l.note}</div>}
                  </li>
                ))}
              </ul>

              <h3 style={{ fontSize: 11, letterSpacing: ".07em",
                           textTransform: "uppercase", color: "var(--ink-soft)",
                           margin: "20px 0 8px" }}>
                What the model was allowed to see
              </h3>
              <ul className="tools">
                {tools.map((t) => (
                  <li key={t} className={called.has(t) ? "called" : "idle"}>
                    <span className="tick">{called.has(t) ? "✓" : "·"}</span>
                    <span className="mono">{t}</span>
                    {called.has(t) && <span style={{ fontSize: 11 }}>called</span>}
                  </li>
                ))}
              </ul>
              <p className="note" style={{ marginTop: 8 }}>
                The model cannot read the database, cannot browse, and knows
                nothing about this farm from training. If a fact is not reachable
                through these functions it cannot appear in the answer.
              </p>

              <div className={`verify${res.generator !== "claude" ? " fallback" : ""}`}>
                {res.generator === "claude" ? (
                  <>Written by <b className="mono">claude</b>. Every figure was
                  checked against the tool results before the answer was returned.</>
                ) : (
                  <>Served by the <b className="mono">deterministic fallback</b>
                  {res.llm?.reason && <> — {res.llm.reason}</>}. The model's answer
                  contained something the evidence did not support, so it was
                  discarded. This state is a feature, not an error.</>
                )}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
