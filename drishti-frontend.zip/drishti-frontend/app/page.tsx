"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Kpis } from "@/components/Kpis";
import { Mix } from "@/components/Mix";
import { StatePill, Strip, StripAxis } from "@/components/Strip";
import { SeasonRatio } from "@/components/SeasonRatio";
import { useEstimator, useRoleLink, withParams } from "@/lib/role";
import {
  Book, History, Portfolio, StripObservation,
  getBook, getHistory, getPortfolio, inr,
} from "@/lib/api";

interface Row {
  farm_id: string; farm_name: string; farmer_name: string; crop: string;
  state: string; days_unseen: number; yield_display: string;
  exposure: number; strip: StripObservation[];
  kharif: number | null; rabi: number | null;
}

function BookPage() {
  const link = useRoleLink();
  // With the unfitted estimator nothing clears a gate, so every radar pass
  // routes to BLIND. Rendering that here rather than describing it is the
  // difference between claiming the gate works and watching it work.
  const unfitted = useEstimator() === "unfitted";
  const [rows, setRows] = useState<Row[] | null>(null);
  const [mix, setMix] = useState<Record<string, number>>({});
  const [atRisk, setAtRisk] = useState(0);
  const [maxUnseen, setMaxUnseen] = useState(0);
  const [book, setBook] = useState<Book | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const [p, b]: [Portfolio, Book] = await Promise.all([getPortfolio(), getBook()]);
        const exp = Object.fromEntries(b.rows.map((r) => [r.farm_id, r.outstanding_inr]));
        const hist = await Promise.all(
          p.rows.map((r) => getHistory(r.farm_id).catch(() => null)));

        const merged: Row[] = p.rows.map((r, i) => {
          const h: History | null = hist[i];
          return {
            farm_id: r.farm_id, farm_name: r.farm_name, farmer_name: r.farmer_name,
            crop: r.crop, state: r.state,
            days_unseen: r.days_since_last_clear_optical,
            yield_display: r.yield.display,
            exposure: exp[r.farm_id] ?? 0,
            strip: h?.available ? h.observations : [],
            kharif: h?.clear_share?.kharif ?? null,
            rabi: h?.clear_share?.rabi ?? null,
          };
        });

        // Ranked by exposure at risk, not alphabetically. The monsoon band still
        // forms because it hit every farm — but the order is a worklist.
        merged.sort((a, c) => c.exposure * c.days_unseen - a.exposure * a.days_unseen);

        setRows(merged);
        setMix(p.confidence_mix_by_area);
        setBook(b);
        setAtRisk((b.exposure_by_state_inr.Blind ?? 0)
                + (b.exposure_by_state_inr.Degraded ?? 0));
        setMaxUnseen(Math.max(...merged.map((m) => m.days_unseen)));
      } catch (e: any) { setErr(e.message); }
    })();
  }, []);

  if (err) return <p className="note" style={{ paddingTop: 30 }}>
    The book could not be loaded ({err}). The service may be redeploying.</p>;
  if (!rows) return <p className="loading">Reading the season…</p>;

  const breaches = rows.filter((r) => r.days_unseen > 18).length;
  const kh = rows.map((r) => r.kharif).filter((x): x is number => x != null);
  const rb = rows.map((r) => r.rabi).filter((x): x is number => x != null);
  const avg = (a: number[]) => a.length ? a.reduce((s, x) => s + x, 0) / a.length : 0;
  const ratio = avg(kh) > 0 ? (avg(rb) / avg(kh)).toFixed(1) : "—";

  return (
    <>
      {/* The hero is a sentence. A large figure with a small label is the
          default dashboard treatment and is what makes the source product
          read as a government form. */}
      {unfitted && (
        <div style={{ border: "1px solid var(--risk)", background: "#FFF7F6",
                      borderRadius: 4, padding: "12px 16px", marginTop: 18 }}>
          <b style={{ font: "600 13px Inter", color: "var(--risk)" }}>
            Estimator 0.1.0-unfitted
          </b>
          <p className="note" style={{ margin: "5px 0 0" }}>
            No radar model has cleared a gate, so every cloud-obscured pass
            routes to BLIND. This is what the product looks like before the
            confidence layer does anything — every band below becomes a range
            and every estimate disappears.
          </p>
        </div>
      )}

      <div className="hero">
        <div style={{ maxWidth: 620 }}>
          <h1>{inr(atRisk)} of your book has not been clearly seen in {maxUnseen} days</h1>
          <p>
            Across two years these fields are clear on {Math.round(avg(rb) * 100)}% of
            Rabi passes and {Math.round(avg(kh) * 100)}% of Kharif ones. The satellite
            sees them {ratio} times better in the season when nothing is at risk —
            Rabi is irrigated and stable; Kharif is when the crop is rainfed and
            the loan is outstanding.
          </p>
        </div>
        <Mix mix={mix} />
      </div>

      <SeasonRatio kharif={avg(kh)} rabi={avg(rb)} />

      <Kpis items={[
        { label: "exposure not clearly seen", value: inr(atRisk), tone: "warn" },
        { label: "borrowers", value: String(book?.borrowers ?? rows.length) },
        { label: "book value", value: inr(book?.total_exposure_inr ?? 0) },
        { label: "over SLA budget", value: String(breaches),
          tone: breaches ? "bad" : undefined },
        { label: "longest unseen", value: `${maxUnseen}d`, tone: "warn" },
        { label: "clear in Kharif", value: `${Math.round(avg(kh) * 100)}%`, tone: "warn" },
      ]} />

      <div className="listhead">
        <span />
        <div style={{ position: "relative", height: 16 }}>
          {rows[0] && <StripAxis observations={rows[0].strip} />}
        </div>
        <span>state now</span>
        <span style={{ textAlign: "right" }}>yield</span>
        <span style={{ textAlign: "right" }}>exposure</span>
        <span />
      </div>

      <div>
        {rows.map((r, i) => (
          <Link key={r.farm_id} href={link(`/farm/${r.farm_id}`)}
                style={{ color: "inherit", display: "block" }}>
            <div className="striprow">
              <div className="name">
                {r.farm_name}
                <small>{r.farmer_name} · {r.crop}</small>
              </div>
              <Strip observations={r.strip} />
              <StatePill state={unfitted && r.state === "Degraded" ? "Blind" : r.state} />
              <div className="figure">
                {unfitted && r.state === "Degraded"
                  ? <span className="note">no decision-grade value</span>
                  : r.yield_display.split(",")[0]}
              </div>
              <div className="figure">
                {inr(r.exposure)}
                <small>{r.days_unseen > 900 ? "never seen" : `${r.days_unseen}d unseen`}</small>
              </div>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                   stroke="var(--ink-ghost)" strokeWidth="2">
                <path d="M9 6l6 6-6 6" />
              </svg>
            </div>
          </Link>
        ))}
      </div>

      <p className="note" style={{ marginTop: 20 }}>
        Bar height is the NDVI reading; the 3px row beneath the line is the
        confidence state. Solid is measured, hatched is estimated from radar,
        and nothing at all is not observed — no bar and no tick. Shaded bands
        are the monsoon, which is where the ink disappears.
      </p>
    </>
  );
}

export default withParams(BookPage);
