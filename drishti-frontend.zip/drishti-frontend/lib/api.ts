/**
 * The one rule this client must not break: render `display` verbatim.
 *
 * Every metric arrives already formatted by the precision policy in the
 * backend — a point value when measured, a band when estimated, a range plus
 * "last measured" when unseen. A frontend that formats its own numbers can
 * print 7.2 on a field nobody has looked at in two months, which is the exact
 * defect this product exists to remove.
 *
 * Render `display`. Never `value`.
 */

export const API =
  process.env.NEXT_PUBLIC_API ?? "https://elai-platform-production.up.railway.app";

export type State = "Verified" | "Degraded" | "Blind";

export interface Metric {
  metric: string; state: State; display: string;
  value: number | null; low: number | null; high: number | null;
  unit: string | null; note: string | null;
  last_verified_date: string | null; last_verified_das: number | null;
  rule_version: string;
}

export interface PortfolioRow {
  farm_id: string; farm_name: string; farmer_name: string; district: string;
  crop: string; area_ha: number; das: number; stage: string; state: State;
  cloudy: boolean; days_since_last_clear_optical: number;
  last_verified_date: string | null; rung_label: string; yield: Metric;
  polygon: [number, number][]; centroid: [number, number];
}

export interface Portfolio {
  data_source: string; farm_count: number; total_area_ha: number;
  confidence_mix_by_area: Record<State, number>; rows: PortfolioRow[];
}

export interface StripObservation {
  date: string; state: "measured" | "estimated" | "unseen";
  valid_pixel_fraction: number; ndvi: number | null;
  season: "kharif" | "rabi" | "other";
}

export interface History {
  farm_id: string; farm_name?: string; crop?: string;
  available: boolean; reason?: string;
  observations: StripObservation[];
  span?: { from: string; to: string } | null;
  clear_share?: { overall: number | null; kharif: number | null; rabi: number | null };
  finding?: string;
}

export interface Health {
  status: string; rule_version: string; data_source: string;
  estimator_version: string; validated_models: string[];
  estimator_fallback_reason: string | null; core_states: string[];
}

export interface BookRow {
  farm_id: string; borrower: string; district: string; crop: string;
  outstanding_inr: number; due_date: string; predicted_harvest_date: string;
  days_due_before_harvest: number; confidence_state: State;
  match_tier: string; last_verified_date: string | null;
}

export interface Book {
  as_of: string; borrowers: number; total_exposure_inr: number;
  exposure_by_state_inr: Record<State, number>;
  exposure_by_state_share: Record<State, number>;
  rule: string; rows: BookRow[];
}

export interface EvidenceLink {
  index: string; obs_date: string; das: number | null;
  value: number | null; uncertainty: number | null;
  stage?: string; state: string; cloud_state?: string;
  valid_pixel_fraction?: number; source?: string; rung?: string;
  rule_version?: string; note?: string;
  rejected?: { uncertainty?: number; ceiling?: number };
  rejected_note?: string;
}

export interface Explain {
  farm_id: string; audience: string; refused: boolean;
  refusal_reason?: string; answer: string; confidence_state: State;
  evidence_chain: EvidenceLink[]; escalated: boolean;
  escalation_target?: string; guardrails_applied: string[];
  generator: string; llm?: { attempted?: boolean; reason?: string };
  rule_version: string;
}

async function get<T>(path: string): Promise<T> {
  const r = await fetch(`${API}${path}`, { cache: "no-store" });
  if (!r.ok) throw new Error(`${path} → ${r.status}`);
  return r.json();
}

export const getHealth        = () => get<Health>("/healthz");
export const getPortfolio     = () => get<Portfolio>("/v1/portfolio");
export const getBook          = () => get<Book>("/v1/lenderbook/book");
export const getCallList      = () => get<any>("/v1/lenderbook/call-list");
export const getHistory       = (id: string) => get<History>(`/v1/farms/${id}/history`);
export const getFarmState     = (id: string) => get<any>(`/v1/farms/${id}/state`);
export const getCoverage      = (id: string) => get<any>(`/v1/coverage/${id}`);
export const getObservations  = (id: string) => get<any[]>(`/v1/farms/${id}/observations`);
export const getStageWeights  = (id: string) => get<any>(`/v1/farms/${id}/stage-weights`);
export const getTools         = () => get<any>("/v1/agent/tools");
export const getTenants       = () => get<any>("/v1/tenancy");
export const getTenantView    = (t: string, f: string) =>
  get<any>(`/v1/tenancy/${t}/view/${f}`);
export const getKisanQueue    = (lang = "te") =>
  get<any>(`/v1/kisanvoice/queue?language=${lang}`);
export const getPolicy        = () => get<any>("/v1/tenancy/policy");

export async function explain(
  farm_id: string, audience = "lender", question?: string,
): Promise<Explain> {
  const r = await fetch(`${API}/v1/agent/explain`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ farm_id, audience, question }),
  });
  if (!r.ok) throw new Error(`explain → ${r.status}`);
  return r.json();
}

/** Rupees, in the units an Indian credit officer actually uses. */
export function inr(n: number): string {
  if (n >= 1e7) return `₹${(n / 1e7).toFixed(2)} cr`;
  if (n >= 1e5) return `₹${(n / 1e5).toFixed(2)} L`;
  return `₹${n.toLocaleString("en-IN")}`;
}

export function shortDate(iso: string | null | undefined): string {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("en-IN",
    { day: "numeric", month: "short" });
}

export function pct(x: number | null | undefined): string {
  return x == null ? "—" : `${Math.round(x * 100)}%`;
}
