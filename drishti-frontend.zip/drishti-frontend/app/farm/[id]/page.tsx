"use client";

import { use, useEffect, useState } from "react";
import { ExplainPanel } from "@/components/Explain";
import { Strip, StripAxis } from "@/components/Strip";
import { getCoverage, getFarmState, getHistory, getStageWeights, shortDate } from "@/lib/api";
import Link from "next/link";
import { useRole } from "@/lib/role";

/**
 * `params` is a Promise in Next 15+ and a plain object in 14.
 *
 * Reading `params.id` directly on 15 yields undefined and every request goes to
 * /v1/farms/undefined; calling `use()` on 14 throws "an unsupported type was
 * passed to use()". Both happened. Detecting which one we were handed is two
 * lines and removes a whole class of version-coupling from the page.
 */
export default function Farm({ params }: { params: any }) {
  const resolved: { id: string } =
    typeof params?.then === "function" ? use(params) : params;
  const id = resolved.id;
  const role = useRole();

  // Back goes to the role's OWN home, not to the credit officer's book. An
  // assessor who lands on the lender's worklist has been moved to someone
  // else's job.
  const HOME: Record<string, [string, string]> = {
    lender: ["/", "book"],
    field: ["/map", "map"],
    insurer: ["/timeline", "chronology"],
    exporter: ["/weeks", "delivery weeks"],
  };
  const [homeHref, homeLabel] = HOME[role] ?? HOME.lender;
  const back = role === "lender" ? homeHref : `${homeHref}?role=${role}`;
  const [state, setState] = useState<any>(null);
  const [hist, setHist] = useState<any>(null);
  const [cov, setCov] = useState<any>(null);
  const [weights, setWeights] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const [s, h, c, w] = await Promise.all([
          getFarmState(id),
          getHistory(id).catch(() => null),
          getCoverage(id).catch(() => null),
          getStageWeights(id).catch(() => null),
        ]);
        setState(s); setHist(h); setCov(c); setWeights(w);
      } catch (e: any) { setErr(e.message); }
    })();
  }, [id]);

  if (err) return <p className="note" style={{ paddingTop: 30 }}>{err}</p>;
  if (!state) return <p className="loading">Reading the field…</p>;

  const obs = state.observation;
  const stress = state.stress;
  const yieldM = state.metrics.find((m: any) => m.metric === "predicted_productivity");

  return (
    <div style={{ paddingTop: 22 }}>
      <h1 style={{ fontSize: 22, fontWeight: 600, margin: "0 0 3px" }}>
        {hist?.farm_name ?? id}
      </h1>
      <p style={{ margin: "0 0 6px" }}>
        <Link href={back} style={{ fontSize: 12 }}>← back to {homeLabel}</Link>
      </p>
      <p className="context" style={{ margin: 0 }}>
        {state.stage.replace("_", " ")} · day {state.das} after sowing ·
        as of {shortDate(state.as_of)} · <span className="mono">{id}</span>
      </p>

      {hist?.available && (
        <div style={{ margin: "24px 0 4px" }}>
          <Strip observations={hist.observations} height={56} />
          <StripAxis observations={hist.observations} />
          <p className="note" style={{ marginTop: 10 }}>
            Clear on {Math.round((hist.clear_share?.rabi ?? 0) * 100)}% of Rabi
            passes and {Math.round((hist.clear_share?.kharif ?? 0) * 100)}% of
            Kharif ones.
          </p>
        </div>
      )}

      {/* One answer, in the precision the confidence state allows. The source
          product stacks five sections of equal weight; this has one answer,
          then evidence, then method. */}
      <dl className="answer">
        <dt>Yield</dt>
        <dd>{yieldM.display}{yieldM.note && <em>{yieldM.note}</em>}</dd>

        <dt>Stress</dt>
        <dd>
          {stress.band}
          <em>
            {stress.score === null
              ? `${Math.round(stress.weight_covered * 100)}% of the stage's index weight was available — not enough to issue a verdict, which is not the same as no stress`
              : `driven by ${stress.driving_index}`}
          </em>
        </dd>

        {/* last_verified_date is carried on the METRIC, not the observation.
            Reading it off the observation yields undefined and every field
            renders "not this season" regardless of its actual history. */}
        <dt>Last measured</dt>
        <dd>
          {yieldM.last_verified_date
            ? shortDate(yieldM.last_verified_date)
            : "not this season"}
          <em>
            {obs.days_since_last_clear_optical > 900
              ? "no clear optical pass recorded"
              : `${obs.days_since_last_clear_optical} days ago`}
            {yieldM.last_verified_das != null && ` · day ${yieldM.last_verified_das}`}
          </em>
        </dd>

        {cov && (
          <>
            <dt>Coverage</dt>
            <dd>
              {cov.blind_days_this_season} of {cov.blind_days_budget} blind days used
              <em>{cov.in_breach ? "SLA in breach" : "within the SLA budget"}
                {cov.escalation_recommended &&
                  ` · escalation available at ₹${cov.escalation_cost_inr}`}</em>
            </dd>
          </>
        )}
      </dl>

      <ExplainPanel farmId={id} />

      {/* Krupa asked directly how index importance is weighted by growth stage.
          It is data, not a slide. */}
      {weights?.indices?.length > 0 && (
        <details className="more">
          <summary>How stress is weighted at {weights.stage?.replace("_", " ")}</summary>
          <table className="data">
            <thead>
              <tr><th>Index</th><th>Stage weight</th><th>Direction</th>
                  <th>Healthy</th><th>Stressed</th><th>Status</th></tr>
            </thead>
            <tbody>
              {weights.indices.map((i: any) => (
                <tr key={i.index}>
                  <td className="mono">{i.index}</td>
                  <td>{i.weight.toFixed(2)}</td>
                  <td>{i.direction === "up" ? "rising is stress" : "falling is stress"}</td>
                  <td>{i.healthy ?? "—"}</td>
                  <td>{i.stressed ?? "—"}</td>
                  <td className="note">{i.threshold_status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </details>
      )}

      {/* Method, not consequence — so it sits behind a disclosure. Uncertainty
          is a decision consequence and stays on the surface above. */}
      <details className="more">
        <summary>How this reading was produced</summary>
        <dl className="answer">
          <dt>Source</dt><dd style={{ fontSize: 14 }}>{obs.rung_label}</dd>
          <dt>NDVI</dt>
          <dd style={{ fontSize: 14 }}>
            {obs.ndvi === null ? "not observed" : obs.ndvi.toFixed(3)}
            {obs.ndvi_uncertainty != null &&
              <em>error band ±{obs.ndvi_uncertainty.toFixed(3)}</em>}
          </dd>
          <dt>Clear pixels</dt>
          <dd style={{ fontSize: 14 }}>{Math.round(obs.valid_pixel_fraction * 100)}%</dd>
          <dt>Engine</dt>
          <dd style={{ fontSize: 14 }}>
            <span className="mono">{obs.rule_version}</span>
            <em>{obs.reason}</em>
          </dd>
        </dl>
      </details>
    </div>
  );
}
