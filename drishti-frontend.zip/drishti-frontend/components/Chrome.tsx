"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEstimator, useRole } from "@/lib/role";

/**
 * Header, role switcher and navigation.
 *
 * The switcher changes WHERE YOU LAND, not just what the tabs are called.
 *
 * Jital's account of why the company exists is that five people read the same
 * dashboard about the same farm and each misread it, because each needed a
 * different answer. A switcher that relabels tabs and shows the same screen
 * demonstrates the opposite of the fix — so each role opens on its own first
 * question:
 *
 *   credit officer     who do I call this week          -> the book
 *   field supervisor   where do I go today              -> the map
 *   claims assessor    what happened, and when          -> the chronology
 *   procurement        how much, arriving when          -> delivery weeks
 *
 * Same engine, same confidence states, same rule version. Four different first
 * screens.
 */
const ROLES = {
  lender: {
    label: "credit officer",
    home: "/",
    nav: [
      { href: "/", label: "Book" },
      { href: "/calls", label: "Call list" },
      { href: "/coverage", label: "Coverage" },
      { href: "/evidence", label: "Evidence" },
    ],
  },
  field: {
    label: "field supervisor",
    home: "/map",
    nav: [
      { href: "/map", label: "Map" },
      { href: "/calls", label: "Visits" },
      { href: "/evidence", label: "Capture" },
      { href: "/coverage", label: "Coverage" },
    ],
  },
  insurer: {
    label: "claims assessor",
    home: "/timeline",
    nav: [
      { href: "/timeline", label: "Chronology" },
      { href: "/evidence", label: "Record" },
      { href: "/coverage", label: "Audit" },
      { href: "/", label: "Portfolio" },
    ],
  },
  exporter: {
    label: "procurement manager",
    home: "/weeks",
    nav: [
      { href: "/weeks", label: "Delivery weeks" },
      { href: "/calls", label: "Growers" },
      { href: "/coverage", label: "Coverage" },
      { href: "/evidence", label: "Record" },
    ],
  },
} as const;

type RoleKey = keyof typeof ROLES;

export function Chrome() {
  const router = useRouter();
  const path = usePathname();
  const role = (useRole() as RoleKey);
  const est = useEstimator();
  const cfg = ROLES[role] ?? ROLES.lender;

  const withRole = (href: string) =>
    role === "lender" ? href : `${href}?role=${role}`;

  return (
    <header className="top">
      <div className="topbar">
        <Link href={withRole(cfg.home)} className="wordmark"
              style={{ color: "var(--ink)" }}>
          DRISHTI<i>+</i>
        </Link>
        <span className="context">Kharif 2026 · Telangana · 6 farms · 5.9 ha</span>
        <span className="spacer" />

        {/* The estimator switcher. Flip to `unfitted` and every radar pass
            routes to BLIND — the book re-scores live, and the screen shows what
            this product looked like before any model cleared a gate. It is the
            fastest way to see what the confidence layer is actually doing. */}
        <div className="rolepill">
          <span>estimator</span>
          <select
            value={est}
            onChange={(e) => {
              const u = new URLSearchParams(
                typeof window === "undefined" ? "" : window.location.search);
              if (e.target.value === "fusion") u.delete("est");
              else u.set("est", e.target.value);
              const q = u.toString();
              router.push(`${path}${q ? "?" + q : ""}`);
            }}>
            <option value="fusion">2.0.0-fusion</option>
            <option value="unfitted">0.1.0-unfitted</option>
          </select>
        </div>

        <div className="rolepill">
          <span>role</span>
          <select
            value={role}
            onChange={(e) => {
              const r = e.target.value as RoleKey;
              const home = ROLES[r].home;
              // Land on that role's first question, not on whatever page the
              // previous role happened to be looking at.
              router.push(r === "lender" ? home : `${home}?role=${r}`);
            }}>
            {(Object.keys(ROLES) as RoleKey[]).map((k) => (
              <option key={k} value={k}>{ROLES[k].label}</option>
            ))}
          </select>
        </div>
      </div>
      <nav className="tabs">
        {cfg.nav.map((i) => (
          <Link key={i.href + i.label} href={withRole(i.href)}
                className={path === i.href ? "on" : ""}>
            {i.label}
          </Link>
        ))}
      </nav>
    </header>
  );
}
