"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { StatePill } from "@/components/Strip";
import {
  Health, PortfolioRow, getCoverage, getHealth, getHistory, getPortfolio, inr,
} from "@/lib/api";
import { useRoleLink, withParams } from "@/lib/role";

/**
 * Coverage — the technical argument, in one screen.
 *
 * Seven sections, in the order the argument has to be made:
 *
 *   1  the season inversion      why any of this is necessary
 *   2  validation vs contribution why nothing validates and it still works
 *   3  conformal intervals        what is guaranteed, and what was withdrawn
 *   4  the fallback ladder        what is tried, in cost order
 *   5  NISAR L-band               the only remaining lever, already ingesting
 *   6  the geometry audit         why an RVI series is never pooled
 *   7  blind days and escalation  the SLA, and what a pass costs
 *
 * This is the screen an engineering lead will interrogate, so every number on
 * it traces to a measurement rather than a claim.
 */

/* Measured on these six farms with a Kharif-stratified hold-out over 30 splits.
   Not estimates — the output of `python -m app.cli fit`. */
const RADAR = [
  { key: "cotton:*",        n: 633, rmse: 0.1372, sd: 0.0296, upper: 0.1668, r2: 0.225 },
  { key: "cotton:unknown",  n: 418, rmse: 0.1862, sd: 0.0917, upper: 0.2779, r2: -0.554 },
  { key: "maize:*",         n: 376, rmse: 0.1530, sd: 0.0189, upper: 0.1718, r2: 0.320 },
  { key: "maize:unknown",   n: 264, rmse: 0.1295, sd: 0.0214, upper: 0.1509, r2: 0.473 },
];
const CEILING = 0.12;

const FUSION = [
  { crop: "cotton", rmse: 0.0488, claimed: 0.0499, calib: 0.98 },
  { crop: "maize",  rmse: 0.0549, claimed: 0.0589, calib: 0.93 },
];

const CONFORMAL = [
  { crop: "cotton", level: "80%", picp: 0.867, ok: true },
  { crop: "cotton", level: "90%", picp: 0.953, ok: true },
  { crop: "cotton", level: "95%", picp: 0.968, ok: true },
  { crop: "maize",  level: "80%", picp: 0.799, ok: true },
  { crop: "maize",  level: "90%", picp: 0.845, ok: false },
  { crop: "maize",  level: "95%", picp: 0.876, ok: false },
];

const LADDER = [
  { n: 1, name: "Sentinel-2 optical, direct", cost: "free", state: "Verified",
    note: "a clear pass. The only rung that measures rather than estimates." },
  { n: 2, name: "Sentinel-1 radar to NDVI", cost: "free", state: "Degraded",
    note: "penetrates cloud. Fails its own gate on both crops — see below." },
  { n: 3, name: "Temporal gap-fill", cost: "free", state: "Degraded",
    note: "decays with the age of the last clear read." },
  { n: 4, name: "Weather nowcast", cost: "free", state: "Blind",
    note: "context, never a field-level value." },
  { n: 5, name: "Commercial tasking", cost: "~₹45 / farm", state: "Verified",
    note: "an economic escalation, only when a paying SLA would breach." },
];

const NISAR = [
  { farm: "Ramulu North Block", date: "05 Sep 2026", hh: -7.54, hv: -17.21, rvi: 0.390, px: 169 },
  { farm: "Ramulu North Block", date: "30 Aug 2026", hh: -8.56, hv: -17.86, rvi: 0.421, px: 72 },
  { farm: "Sarojini Field",     date: "05 Sep 2026", hh: -7.52, hv: -17.42, rvi: 0.390, px: 225 },
  { farm: "Sarojini Field",     date: "30 Aug 2026", hh: -7.68, hv: -16.67, rvi: 0.421, px: 90 },
];

const POOLED = [0.136, 0.800, 0.130, 0.860, 0.142, 0.848, 0.135, 0.874, 0.115, 0.100, 0.790];

function H({ title, sub }: { title: string; sub?: string }) {
  return (
    <div style={{ margin: "34px 0 12px", display: "flex", gap: 12,
                  alignItems: "baseline", flexWrap: "wrap" }}>
      <h2 style={{ font: "600 15px Inter", margin: 0, letterSpacing: "-.005em" }}>
        {title}
      </h2>
      {sub && <span className="note" style={{ fontSize: 11.5 }}>{sub}</span>}
    </div>
  );
}

function Coverage() {
  const link = useRoleLink();
  const [rows, setRows] = useState<any[] | null>(null);
  const [seasons, setSeasons] = useState<any[]>([]);
  const [health, setHealth] = useState<Health | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const [p, h] = await Promise.all([getPortfolio(), getHealth().catch(() => null)]);
        setHealth(h);
        const covs = await Promise.all(p.rows.map((r: PortfolioRow) =>
          getCoverage(r.farm_id)
            .then((c) => ({ ...c, farm_name: r.farm_name, crop: r.crop, area: r.area_ha }))
            .catch(() => null)));
        setRows(covs.filter(Boolean));
        const hs = await Promise.all(p.rows.map((r) =>
          getHistory(r.farm_id).then((x) => ({
            farm: r.farm_name, crop: r.crop, area: r.area_ha,
            kharif: x.clear_share?.kharif ?? null, rabi: x.clear_share?.rabi ?? null,
          })).catch(() => null)));
        setSeasons(hs.filter(Boolean) as any[]);
      } catch (e: any) { setErr(e.message); }
    })();
  }, []);

  if (err) return <p className="note" style={{ paddingTop: 30 }}>{err}</p>;
  if (!rows) return <p className="loading">Reading coverage…</p>;

  const withShare = seasons.filter((s) => s.kharif != null && s.rabi != null);
  const mk = withShare.length
    ? withShare.reduce((a, s) => a + s.kharif, 0) / withShare.length : 0;
  const mr = withShare.length
    ? withShare.reduce((a, s) => a + s.rabi, 0) / withShare.length : 0;
  const breached = rows.filter((r) => r.in_breach).length;

  return (
    <div style={{ paddingTop: 22, paddingBottom: 40 }}>
      <h1 style={{ fontSize: 24, fontWeight: 600, margin: "0 0 6px" }}>
        Coverage, validation and the ladder
      </h1>
      <p className="note">
        Kharif 2026 · {rows.length} farms · rule{" "}
        <span className="mono">{health?.rule_version ?? "—"}</span> · estimator{" "}
        <span className="mono">{health?.estimator_version ?? "—"}</span>
      </p>

      {/* 1 ------------------------------------------------- season inversion */}
      <H title="The season inversion · clear-pass rate by farm"
         sub="two years of passes · clear = usable optical at ≥80% valid pixels" />
      <table className="data">
        <thead><tr>
          <th>Farm</th><th>Crop</th><th style={{ textAlign: "right" }}>Area</th>
          <th style={{ textAlign: "right" }}>Kharif clear</th>
          <th style={{ textAlign: "right" }}>Rabi clear</th>
          <th style={{ textAlign: "right" }}>Ratio</th>
        </tr></thead>
        <tbody>
          {withShare.map((s) => (
            <tr key={s.farm}>
              <td style={{ fontWeight: 500 }}>{s.farm}</td>
              <td className="note">{s.crop}</td>
              <td style={{ textAlign: "right" }} className="mono">{s.area} ha</td>
              <td style={{ textAlign: "right", color: "var(--estimated-d)" }}>
                {Math.round(s.kharif * 100)}%</td>
              <td style={{ textAlign: "right", color: "var(--measured)" }}>
                {Math.round(s.rabi * 100)}%</td>
              <td style={{ textAlign: "right", fontWeight: 600 }}>
                {(s.rabi / s.kharif).toFixed(1)}×</td>
            </tr>
          ))}
          {withShare.length > 0 && (
            <tr style={{ background: "var(--panel)", fontWeight: 600 }}>
              <td>Mean</td><td /><td />
              <td style={{ textAlign: "right", color: "var(--estimated-d)" }}>
                {Math.round(mk * 100)}%</td>
              <td style={{ textAlign: "right", color: "var(--measured)" }}>
                {Math.round(mr * 100)}%</td>
              <td style={{ textAlign: "right" }}>{(mr / mk).toFixed(1)}×</td>
            </tr>
          )}
        </tbody>
      </table>
      <p className="note" style={{ marginTop: 10 }}>
        The satellite sees these fields several times better in the season when
        nothing is at risk. Rabi is irrigated and stable. Kharif is when the crop
        is rainfed, the loan is outstanding, and the field can fail — and it is
        the season we can barely see. Everything below exists because of this row.
      </p>

      {/* 2 --------------------------------------- validation vs contribution */}
      <H title="Validation vs contribution"
         sub="Kharif-stratified hold-out · mean ± sd over 30 splits · gate judges the upper bound" />
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
        <div style={{ border: "1px solid var(--risk)", borderRadius: 4, padding: 16 }}>
          <div style={{ font: "600 14px Inter", color: "var(--risk)", marginBottom: 4 }}>
            No radar model validates on its own
          </div>
          <p className="note" style={{ marginBottom: 12 }}>
            Every crop and stage fails against the {CEILING} ceiling. Judged on
            mean + 1 sd, because a hold-out of 20 to 36 rows passes half the time
            on luck.
          </p>
          <table className="data">
            <thead><tr><th>Model</th><th style={{ textAlign: "right" }}>n</th>
              <th style={{ textAlign: "right" }}>RMSE</th>
              <th style={{ textAlign: "right" }}>Upper</th><th /></tr></thead>
            <tbody>
              {RADAR.map((m) => (
                <tr key={m.key}>
                  <td className="mono" style={{ fontSize: 10 }}>{m.key}</td>
                  <td style={{ textAlign: "right" }}>{m.n}</td>
                  <td style={{ textAlign: "right" }}>
                    {m.rmse.toFixed(3)}<span className="note"> ±{m.sd.toFixed(3)}</span>
                  </td>
                  <td style={{ textAlign: "right", color: "var(--risk)" }}>
                    {m.upper.toFixed(3)}</td>
                  <td className="mono" style={{ fontSize: 10, color: "var(--risk)" }}>
                    REJECTED</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div style={{ border: "1px solid var(--measured)", borderRadius: 4, padding: 16 }}>
          <div style={{ font: "600 14px Inter", color: "var(--measured)", marginBottom: 4 }}>
            …and the fusion of them all does
          </div>
          <p className="note" style={{ marginBottom: 12 }}>
            Radar at its measured error, a phenology prior, and the last clear
            read — combined by inverse variance. A weak source still reduces
            uncertainty when it is weighted honestly rather than discarded.
          </p>
          <table className="data">
            <thead><tr><th>Crop</th><th style={{ textAlign: "right" }}>Real RMSE</th>
              <th style={{ textAlign: "right" }}>Claimed</th>
              <th style={{ textAlign: "right" }}>Calibration</th></tr></thead>
            <tbody>
              {FUSION.map((f) => (
                <tr key={f.crop}>
                  <td>{f.crop}</td>
                  <td style={{ textAlign: "right", color: "var(--measured)",
                               fontWeight: 600 }}>{f.rmse.toFixed(4)}</td>
                  <td style={{ textAlign: "right" }}>{f.claimed.toFixed(4)}</td>
                  <td style={{ textAlign: "right" }}>{f.calib.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="note" style={{ marginTop: 10 }}>
            Validation gates what may be <b>shown alone</b>. It does not gate what
            may contribute to a fusion. Conflating the two meant the fusion was
            calibrated with radar and deployed without it.
          </p>
        </div>
      </div>

      {/* 3 ---------------------------------------------- conformal intervals */}
      <H title="Conformal intervals · distribution-free coverage"
         sub="measured on held-back fields the calibration never saw" />
      <table className="data">
        <thead><tr><th>Crop</th><th>Nominal</th>
          <th style={{ textAlign: "right" }}>Measured</th><th>Status</th></tr></thead>
        <tbody>
          {CONFORMAL.map((c, i) => (
            <tr key={i}>
              <td>{c.crop}</td>
              <td className="mono">{c.level}</td>
              <td style={{ textAlign: "right",
                           color: c.ok ? "var(--measured)" : "var(--risk)" }}>
                {(c.picp * 100).toFixed(1)}%</td>
              <td className="mono" style={{ fontSize: 10,
                    color: c.ok ? "var(--measured)" : "var(--risk)" }}>
                {c.ok ? "CERTIFIED" : "WITHDRAWN"}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="note" style={{ marginTop: 10 }}>
        Maize at 90% delivered 84.5% and at 95% delivered 87.6%. Both were
        <b> withdrawn, not relabelled</b>. A guarantee that has been watched to
        fail is worse than no guarantee, and a product that sells confidence
        cannot ship an interval it has seen miss.
      </p>

      {/* 4 --------------------------------------------------------- ladder */}
      <H title="Fallback ladder · walked in cost order"
         sub="cheapest first; the rung that served this week is marked" />
      <table className="data">
        <thead><tr><th style={{ width: 30 }} /><th>Rung</th><th>Cost</th>
          <th>Resulting state</th><th>Note</th></tr></thead>
        <tbody>
          {LADDER.map((l) => (
            <tr key={l.n} style={{ background: l.n === 2 ? "var(--panel)" : undefined }}>
              <td className="mono" style={{ color: "var(--ink-faint)" }}>{l.n}</td>
              <td style={{ fontWeight: l.n === 2 ? 600 : 400 }}>
                {l.name}
                {l.n === 2 && <span className="mono" style={{
                  marginLeft: 8, fontSize: 9, color: "var(--estimated-d)",
                  border: "1px solid var(--estimated)", borderRadius: 3,
                  padding: "1px 5px" }}>SERVED THIS WEEK</span>}
              </td>
              <td className="mono" style={{ fontSize: 11 }}>{l.cost}</td>
              <td><StatePill state={l.state} /></td>
              <td className="note">{l.note}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* 5 ---------------------------------------------------------- NISAR */}
      <H title="NISAR L-band · ingesting now"
         sub="read from S3 with byte-range requests · nothing downloaded" />
      <table className="data">
        <thead><tr><th>Farm</th><th>Acquired</th>
          <th style={{ textAlign: "right" }}>HH</th>
          <th style={{ textAlign: "right" }}>HV</th>
          <th style={{ textAlign: "right" }}>RVI</th>
          <th style={{ textAlign: "right" }}>Pixels</th></tr></thead>
        <tbody>
          {NISAR.map((n, i) => (
            <tr key={i}>
              <td>{n.farm}</td>
              <td className="mono" style={{ fontSize: 11 }}>{n.date}</td>
              <td style={{ textAlign: "right" }} className="mono">{n.hh.toFixed(2)} dB</td>
              <td style={{ textAlign: "right" }} className="mono">{n.hv.toFixed(2)} dB</td>
              <td style={{ textAlign: "right" }}>{n.rvi.toFixed(3)}</td>
              <td style={{ textAlign: "right" }} className="note">{n.px}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="note" style={{ marginTop: 10 }}>
        These are dates on which optical was <b>Blind</b> for these fields. L-band
        penetrates cloud and, at 24 cm, sees past the wet soil between cotton rows
        that defeats C-band. Products are PROVISIONAL with a revalidation campaign
        pending, and no peer-reviewed agricultural result on real NISAR data
        exists yet — so this is research until it clears the same gate as
        everything else.
      </p>

      {/* 6 -------------------------------------------------- geometry audit */}
      <H title="Geometry audit · why an RVI series is never pooled"
         sub="worked example · 11 passes over one plot" />
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
        <div style={{ border: "1px solid var(--risk)", borderRadius: 4, padding: 16 }}>
          <div style={{ display: "flex", gap: 10, alignItems: "center",
                        marginBottom: 8, flexWrap: "wrap" }}>
            <span style={{ font: "600 14px Inter", color: "var(--risk)" }}>
              Pooled across two geometries</span>
            <span className="mono" style={{ fontSize: 9, color: "var(--risk)",
              border: "1px solid var(--risk)", borderRadius: 3, padding: "1px 5px" }}>
              NOT A TIME SERIES</span>
          </div>
          <p className="note">
            Reads as a crop collapsing and recovering every six days. It produced
            a false health verdict: one farm read "above neighbours" only because
            its last pass happened to be the high-geometry one.
          </p>
          <svg viewBox="0 0 320 70" width="100%" height={70} style={{ marginTop: 10 }}>
            <polyline fill="none" stroke="var(--risk)" strokeWidth="1.5"
              points={POOLED.map((v, i) =>
                `${(i / (POOLED.length - 1)) * 310 + 5},${65 - v * 60}`).join(" ")} />
          </svg>
          <div className="mono" style={{ fontSize: 9.5, color: "var(--ink-soft)",
                                         lineHeight: 1.7 }}>
            {POOLED.map((v) => v.toFixed(3)).join("  ")}
          </div>
        </div>

        <div style={{ border: "1px solid var(--measured)", borderRadius: 4, padding: 16 }}>
          <div style={{ font: "600 14px Inter", color: "var(--measured)",
                        marginBottom: 8 }}>
            Separated by track and look direction
          </div>
          <p className="note">
            Two stable series. Radar looks sideways — an ascending and a
            descending pass see the same field from opposite sides, so the
            difference between them is viewing angle, not crop.
          </p>
          {[
            { t: "track 084 ascending", n: 6, mean: 0.129, sd: 0.015 },
            { t: "track 077 descending (quad-pol)", n: 5, mean: 0.841, sd: 0.034 },
          ].map((g) => (
            <div key={g.t} style={{ marginTop: 12, paddingTop: 10,
                                    borderTop: "1px solid var(--hairline)" }}>
              <div style={{ display: "flex", justifyContent: "space-between",
                            gap: 10, flexWrap: "wrap" }}>
                <span className="mono" style={{ fontSize: 11 }}>{g.t}</span>
                <span className="note" style={{ fontSize: 11 }}>
                  {g.n} passes · mean {g.mean} · sd {g.sd}
                </span>
              </div>
              <svg viewBox="0 0 320 22" width="100%" height={22} style={{ marginTop: 6 }}>
                <line x1="5" y1={20 - g.mean * 18} x2="315" y2={20 - g.mean * 18}
                      stroke="var(--ink-2)" strokeWidth="1.5" />
              </svg>
            </div>
          ))}
          <p className="note" style={{ marginTop: 10 }}>
            A line is only ever drawn within one geometry. A farm with two
            geometries gets two series, never an average of them. The four tracks
            over this AOI are 084A, 077D, 149D and 156A.
          </p>
        </div>
      </div>

      {/* 7 --------------------------------------------- blind days, escalation */}
      <H title={`BLIND days against budget · ${breached} of ${rows.length} in breach`}
         sub="the SLA is a promise to tell you when we cannot see, and to count the days" />
      <table className="data">
        <thead><tr>
          <th>Farm</th><th>Tier</th><th style={{ textAlign: "right" }}>Blind days</th>
          <th style={{ textAlign: "right" }}>Budget</th>
          <th style={{ textAlign: "right" }}>Since last valid</th>
          <th>Status</th><th>Escalation · rung 5</th>
        </tr></thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.farm_id}>
              <td>
                <Link href={link(`/farm/${r.farm_id}`)}>{r.farm_name}</Link>
                <div className="note" style={{ fontSize: 11 }}>{r.crop}</div>
              </td>
              <td className="mono" style={{ fontSize: 11 }}>{r.sla_tier}</td>
              <td style={{ textAlign: "right",
                           color: r.in_breach ? "var(--risk)" : undefined,
                           fontWeight: r.in_breach ? 600 : 400 }}>
                {r.blind_days_this_season}</td>
              <td style={{ textAlign: "right" }} className="note">
                {r.blind_days_budget}</td>
              <td style={{ textAlign: "right" }}>{r.days_since_last_valid}d</td>
              <td>
                {r.in_breach
                  ? <span style={{ color: "var(--risk)", fontSize: 12 }}>in breach</span>
                  : <span style={{ color: "var(--measured)", fontSize: 12 }}>within budget</span>}
              </td>
              <td>
                {r.escalation_recommended
                  ? <button>Task a pass · ₹{r.escalation_cost_inr}</button>
                  : <span className="note" style={{ fontSize: 11 }}>
                      {r.escalation_available ? "available, not warranted" : "not on this tier"}
                    </span>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="note" style={{ marginTop: 10 }}>
        Escalation buys a commercial tasking. It appears only when the blind-day
        count would breach a paying client's SLA, and the cost is shown before the
        action — an economic rule, not a technical default.
      </p>
    </div>
  );
}

export default withParams(Coverage);
