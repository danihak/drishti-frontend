"use client";

import { PortfolioRow } from "@/lib/api";

/**
 * Farm boundaries, coloured by confidence state.
 *
 * No basemap and no tile provider — the point of this view is not where the
 * fields are in the world, it is which ones cluster together. A supervisor with
 * eight blind farms in two mandals is making one trip, not eight, and that is
 * the only spatial fact this screen has to carry.
 *
 * Drawn as SVG from the polygons the API already returns, projected with a
 * plain equirectangular fit. At this scale — a few kilometres across — the
 * distortion is smaller than the stroke width.
 */

const FILL: Record<string, string> = {
  Verified: "#0E6B5C",
  Degraded: "#C17A1F",
  Blind: "none",
};

export function FarmMap({
  rows, selected, onSelect, height = 420,
}: {
  rows: PortfolioRow[];
  selected?: string | null;
  onSelect?: (id: string) => void;
  height?: number;
}) {
  const pts = rows.flatMap((r) => r.polygon ?? []);
  if (!pts.length) {
    return <p className="note">No boundaries available for these farms.</p>;
  }

  const xs = pts.map((p) => p[0]);
  const ys = pts.map((p) => p[1]);
  const pad = 0.004;
  const minX = Math.min(...xs) - pad, maxX = Math.max(...xs) + pad;
  const minY = Math.min(...ys) - pad, maxY = Math.max(...ys) + pad;
  const W = 900, H = height;
  const sx = (x: number) => ((x - minX) / (maxX - minX)) * W;
  const sy = (y: number) => H - ((y - minY) / (maxY - minY)) * H;

  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={height}
         style={{ border: "1px solid var(--rule)", borderRadius: 4,
                  background: "var(--panel)" }}>
      {/* A faint grid, purely to give the eye a sense of scale. */}
      {[...Array(9)].map((_, i) => (
        <line key={`v${i}`} x1={(i * W) / 8} y1={0} x2={(i * W) / 8} y2={H}
              stroke="var(--hairline)" strokeWidth={1} />
      ))}
      {[...Array(6)].map((_, i) => (
        <line key={`h${i}`} x1={0} y1={(i * H) / 5} x2={W} y2={(i * H) / 5}
              stroke="var(--hairline)" strokeWidth={1} />
      ))}

      {rows.map((r) => {
        const d = (r.polygon ?? [])
          .map((p, i) => `${i ? "L" : "M"}${sx(p[0]).toFixed(1)},${sy(p[1]).toFixed(1)}`)
          .join(" ") + " Z";
        const on = selected === r.farm_id;
        const blind = r.state === "Blind";
        return (
          <g key={r.farm_id} onClick={() => onSelect?.(r.farm_id)}
             style={{ cursor: "pointer" }}>
            <path d={d}
                  fill={blind ? "none" : FILL[r.state]}
                  fillOpacity={blind ? 0 : 0.22}
                  stroke={blind ? "var(--ink-ghost)" : FILL[r.state]}
                  strokeWidth={on ? 3 : 1.5}
                  strokeDasharray={blind ? "5 4" : undefined} />
            <text x={sx(r.centroid[0])} y={sy(r.centroid[1])}
                  textAnchor="middle" dy={-8}
                  style={{ font: "500 11px Inter", fill: "var(--ink)" }}>
              {r.farm_name}
            </text>
            <text x={sx(r.centroid[0])} y={sy(r.centroid[1])}
                  textAnchor="middle" dy={6}
                  style={{ font: "500 9px 'JetBrains Mono',monospace",
                           fill: blind ? "var(--ink-faint)" : FILL[r.state] }}>
              {r.state === "Blind" ? `NOT SEEN ${r.days_since_last_clear_optical}d`
                                   : r.state.toUpperCase()}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
