"use client";

import { useEffect, useState } from "react";
import { Health, getHealth } from "@/lib/api";

/**
 * The provenance strip.
 *
 * Persistent, quiet, always live. It is the running answer to "is what I am
 * looking at real?", and no competitor ships one.
 *
 * When the estimator has fallen back it turns amber and says so, because a
 * system announcing its own degradation is the entire brand.
 */
export function Provenance() {
  const [h, setH] = useState<Health | null>(null);
  const [err, setErr] = useState(false);

  useEffect(() => {
    getHealth().then(setH).catch(() => setErr(true));
  }, []);

  if (err) {
    return (
      <div className="provenance degraded">
        <span>the platform did not respond; nothing on this screen is live</span>
      </div>
    );
  }
  if (!h) return null;

  const degraded = Boolean(h.estimator_fallback_reason);

  return (
    <div className={`provenance${degraded ? " degraded" : ""}`}>
      <span>data <b className="mono">{h.data_source}</b></span>
      <span>rules <b className="mono">{h.rule_version}</b></span>
      <span>estimator <b className="mono">{h.estimator_version}</b></span>
      <span>
        validated{" "}
        <b className="mono">
          {h.validated_models.length ? h.validated_models.join(" ") : "none standalone"}
        </b>
      </span>
      {degraded && <span>fallback: {h.estimator_fallback_reason}</span>}
    </div>
  );
}
