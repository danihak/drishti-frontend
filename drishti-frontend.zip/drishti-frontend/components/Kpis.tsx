"use client";

/**
 * The KPI strip. Six figures, always visible, never decorative.
 *
 * Each one is a number a credit officer would otherwise have to assemble by
 * hand, and the two that matter most — exposure not clearly seen, and SLA
 * breaches — are the ones no competitor can compute at all.
 */
export function Kpis({ items }: {
  items: { label: string; value: string; tone?: "warn" | "bad" }[];
}) {
  return (
    <div className="kpis">
      {items.map((k) => (
        <div key={k.label} className={`kpi${k.tone ? " " + k.tone : ""}`}>
          <b>{k.value}</b>
          <span>{k.label}</span>
        </div>
      ))}
    </div>
  );
}
