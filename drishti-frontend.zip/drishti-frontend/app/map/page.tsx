"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { FarmMap } from "@/components/FarmMap";
import { StatePill } from "@/components/Strip";
import { PortfolioRow, getKisanQueue, getPortfolio } from "@/lib/api";
import { useRoleLink, withParams } from "@/lib/role";

/**
 * FIELD SUPERVISOR — "where do I go today?"
 *
 * The credit officer's question is who to call; this one is spatial, and the
 * answer is a route rather than a list. Eight blind farms in two mandals is one
 * trip, not eight — and that is only visible on a map.
 *
 * What a supervisor sees and a credit officer does not: the farmer's message
 * queue. A field visit that does not collect a label is a wasted trip, so the
 * two-tap question already sent to that farmer is shown before they set off.
 */
function MapPage() {
  const link = useRoleLink();
  const [rows, setRows] = useState<PortfolioRow[] | null>(null);
  const [queue, setQueue] = useState<any[]>([]);
  const [sel, setSel] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const [p, q] = await Promise.all([
          getPortfolio(),
          getKisanQueue("en").catch(() => ({ queue: [] })),
        ]);
        // Worst first. A supervisor's day is finite and the unseen fields are
        // the ones no other part of the system can resolve.
        const sorted = [...p.rows].sort(
          (a, b) => b.days_since_last_clear_optical - a.days_since_last_clear_optical);
        setRows(sorted);
        setQueue(q.queue ?? []);
        if (sorted.length) setSel(sorted[0].farm_id);
      } catch (e: any) { setErr(e.message); }
    })();
  }, []);

  if (err) return <p className="note" style={{ paddingTop: 30 }}>{err}</p>;
  if (!rows) return <p className="loading">Loading the round…</p>;

  const blind = rows.filter((r) => r.state === "Blind");
  const chosen = rows.find((r) => r.farm_id === sel);
  const msg = queue.find((q) => q.farm_id === sel && q.send);

  return (
    <div style={{ paddingTop: 22 }}>
      <h1 style={{ fontSize: 22, fontWeight: 600, margin: "0 0 6px" }}>
        {blind.length > 0
          ? `${blind.length} fields need a visit — nothing else can resolve them`
          : "No field is currently unresolvable from orbit"}
      </h1>
      <p className="note">
        Ordered by how long each field has gone unseen. A visit is the only way
        to turn a Blind field into a fact, and a visit that does not collect a
        label is a wasted trip — so the question already sent to each farmer is
        shown before you set off.
      </p>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 320px",
                    gap: 20, marginTop: 20, alignItems: "start" }}>
        <FarmMap rows={rows} selected={sel} onSelect={setSel} />

        <div>
          {rows.map((r) => (
            <div key={r.farm_id} onClick={() => setSel(r.farm_id)}
                 style={{
                   padding: "10px 12px", cursor: "pointer", borderRadius: 4,
                   border: `1px solid ${r.farm_id === sel ? "var(--ink)" : "transparent"}`,
                   background: r.farm_id === sel ? "#fff" : "transparent",
                   borderBottom: r.farm_id === sel
                     ? "1px solid var(--ink)" : "1px solid var(--hairline)",
                 }}>
              <div style={{ display: "flex", justifyContent: "space-between",
                            alignItems: "center", gap: 8 }}>
                <span style={{ font: "600 13px Inter" }}>{r.farm_name}</span>
                <StatePill state={r.state} />
              </div>
              <div className="note" style={{ fontSize: 11, marginTop: 3 }}>
                {r.farmer_name} · {r.crop} · {r.area_ha} ha ·{" "}
                {r.days_since_last_clear_optical > 900
                  ? "never seen clearly"
                  : `${r.days_since_last_clear_optical}d unseen`}
              </div>
            </div>
          ))}
        </div>
      </div>

      {chosen && (
        <div style={{ marginTop: 22, border: "1px solid var(--ink)",
                      borderRadius: 4, padding: "16px 18px", background: "#fff" }}>
          <div style={{ display: "flex", justifyContent: "space-between",
                        alignItems: "baseline", flexWrap: "wrap", gap: 10 }}>
            <h2 style={{ font: "600 16px Inter", margin: 0 }}>
              {chosen.farm_name} · {chosen.farmer_name}
            </h2>
            <Link href={link(`/farm/${chosen.farm_id}`)} style={{ fontSize: 12 }}>
              full record →
            </Link>
          </div>

          {msg ? (
            <>
              <p className="note" style={{ margin: "10px 0 6px" }}>
                Already sent to this farmer, in {msg.state === "Blind"
                  ? "the blind state" : "the estimated state"}:
              </p>
              <p style={{ font: "400 13.5px/1.5 Inter", background: "var(--panel)",
                          padding: "10px 12px", borderRadius: 4, margin: 0 }}>
                {msg.message}
              </p>
              <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
                {(msg.options ?? []).map((o: any) => (
                  <button key={o.id}>{o.en}</button>
                ))}
              </div>
              <p className="note" style={{ marginTop: 10 }}>
                Recording the answer here writes the same label the farmer's
                reply would. It does not change what the satellite saw.
              </p>
            </>
          ) : (
            <p className="note" style={{ marginTop: 10 }}>
              No message queued for this farmer this week.
            </p>
          )}

          <div className="actions">
            <button className="primary">Log a visit</button>
            <button>Capture a photo with GPS</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default withParams(MapPage);
