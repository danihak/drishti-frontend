"use client";

import { useEffect, useState } from "react";
import { StatePill } from "@/components/Strip";
import { PortfolioRow, getCallList, getPortfolio, shortDate } from "@/lib/api";

/**
 * PROCUREMENT — "how much, arriving when, and how sure?"
 *
 * The exporter does not want a yield figure. They want a tonnage they can sign
 * a contract against, bucketed by delivery week, with a commit-or-hold call on
 * each bucket.
 *
 * THE DESIGN DECISION THAT MATTERS: a commitment is made against the LOW end of
 * the band, never the mid-point. An exporter who commits to the middle of a
 * range is wrong half the time, and being wrong in this direction means
 * defaulting on a shipment. The system therefore shows the floor as the
 * commitable figure and the rest as upside.
 */
export default function Weeks() {
  const [rows, setRows] = useState<PortfolioRow[] | null>(null);
  const [calls, setCalls] = useState<any[]>([]);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const [p, c] = await Promise.all([getPortfolio(), getCallList()]);
        setRows(p.rows);
        setCalls(c.rows ?? []);
      } catch (e: any) { setErr(e.message); }
    })();
  }, []);

  if (err) return <p className="note" style={{ paddingTop: 30 }}>{err}</p>;
  if (!rows) return <p className="loading">Building the commit plan…</p>;

  // Bucket by the week the harvest is predicted to fall in.
  const buckets: Record<string, { rows: PortfolioRow[]; low: number;
                                  high: number; worst: string }> = {};
  const rank: Record<string, number> = { Verified: 0, Degraded: 1, Blind: 2 };

  rows.forEach((r) => {
    const call = calls.find((c) => c.farm_id === r.farm_id);
    if (!call?.predicted_harvest_date) return;
    const d = new Date(call.predicted_harvest_date);
    const monday = new Date(d);
    monday.setDate(d.getDate() - ((d.getDay() + 6) % 7));
    const key = monday.toISOString().slice(0, 10);

    const lo = r.yield.low ?? r.yield.value ?? 0;
    const hi = r.yield.high ?? r.yield.value ?? 0;
    const b = buckets[key] ?? { rows: [], low: 0, high: 0, worst: "Verified" };
    b.rows.push(r);
    b.low += lo * r.area_ha;
    b.high += hi * r.area_ha;
    if (rank[r.state] > rank[b.worst]) b.worst = r.state;
    buckets[key] = b;
  });

  const weeks = Object.entries(buckets).sort(([a], [b]) => a.localeCompare(b));
  const totalFloor = weeks.reduce((s, [, b]) => s + b.low, 0);
  const maxHigh = Math.max(1, ...weeks.map(([, b]) => b.high));

  return (
    <div style={{ paddingTop: 22 }}>
      <h1 style={{ fontSize: 22, fontWeight: 600, margin: "0 0 6px" }}>
        {totalFloor.toFixed(1)} MT can be committed across {weeks.length} delivery weeks
      </h1>
      <p className="note">
        The committable figure is the <b>low end</b> of each band, never the
        middle. An exporter who signs against a mid-point is wrong half the time,
        and wrong in this direction means defaulting on a shipment. Everything
        above the floor is upside, not supply.
      </p>

      <div style={{ marginTop: 22 }}>
        {weeks.map(([week, b]) => {
          const commit = b.worst !== "Blind";
          return (
            <div key={week} style={{
              display: "grid", gridTemplateColumns: "120px 1fr 150px 120px",
              gap: 16, alignItems: "center", padding: "14px 0",
              borderBottom: "1px solid var(--hairline)",
            }}>
              <div>
                <div style={{ font: "600 13px Inter" }}>{shortDate(week)}</div>
                <div className="note" style={{ fontSize: 11 }}>
                  {b.rows.length} {b.rows.length === 1 ? "grower" : "growers"}
                </div>
              </div>

              {/* The band, drawn. The solid part is what can be signed for; the
                  hatched part is what might also arrive. */}
              <div style={{ position: "relative", height: 26 }}>
                <div style={{
                  position: "absolute", left: 0, top: 3, height: 20,
                  width: `${(b.low / maxHigh) * 100}%`,
                  background: "var(--measured)", opacity: 0.85,
                }} />
                <div style={{
                  position: "absolute", left: `${(b.low / maxHigh) * 100}%`, top: 3,
                  height: 20, width: `${((b.high - b.low) / maxHigh) * 100}%`,
                  background: "repeating-linear-gradient(45deg,#C17A1F 0 2px,transparent 2px 5px)",
                  border: "1px solid var(--estimated)", borderLeft: "none",
                }} />
                <i style={{ position: "absolute", left: 0, right: 0, bottom: 0,
                            height: 1, background: "var(--rule)", display: "block" }} />
              </div>

              <div className="figure" style={{ textAlign: "left" }}>
                <b style={{ font: "600 15px Inter" }}>{b.low.toFixed(1)} MT</b>
                <small>floor · up to {b.high.toFixed(1)} MT</small>
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: 6,
                            alignItems: "flex-start" }}>
                <StatePill state={b.worst} />
                <span style={{
                  font: "500 11px Inter",
                  color: commit ? "var(--measured)" : "var(--risk)",
                }}>
                  {commit ? "commit the floor" : "hold — nothing verified"}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      <p className="note" style={{ marginTop: 18 }}>
        A week inherits the <b>weakest</b> confidence state among its growers. One
        unseen field in a delivery week makes the whole week's tonnage an
        estimate, because that is what it is.
      </p>
    </div>
  );
}
