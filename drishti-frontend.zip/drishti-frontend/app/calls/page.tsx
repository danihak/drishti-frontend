"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { StatePill } from "@/components/Strip";
import { getCallList, inr, shortDate } from "@/lib/api";
import { useRoleLink, withParams } from "@/lib/role";

/**
 * The call list.
 *
 * Ordered by when the crop is actually ready, not by a risk score. The
 * officer's weekly question is "who do I call this week", and a loan maturing
 * BEFORE the crop is ready is the collection problem — so that row is marked,
 * weeks before it becomes one.
 *
 * Note that the harvest date carries its own confidence. A call scheduled off a
 * Blind harvest window is a call scheduled off a guess, and the officer should
 * be able to see which of their calls those are.
 */
function Calls() {
  const link = useRoleLink();
  const [data, setData] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    getCallList().then(setData).catch((e) => setErr(e.message));
  }, []);

  if (err) return <p className="note" style={{ paddingTop: 30 }}>
    The call list could not be loaded ({err}).</p>;
  if (!data) return <p className="loading">Building the call list…</p>;

  const rows: any[] = data.rows ?? [];
  const early = rows.filter((r) => r.due_before_harvest).length;
  const uncertain = rows.filter((r) => r.harvest_confidence !== "Verified").length;

  return (
    <div style={{ paddingTop: 22 }}>
      <h1 style={{ fontSize: 22, fontWeight: 600, margin: "0 0 6px" }}>
        {rows.length} borrowers to contact
      </h1>
      <p className="note">
        Ordered by when the crop is actually ready, not by a risk score.
        {early > 0 && <> {early} {early === 1 ? "loan matures" : "loans mature"} before
          harvest — that is the collection problem, visible here weeks before it
          becomes one.</>}
        {uncertain > 0 && <> {uncertain} of these harvest windows are themselves
          estimates, marked below.</>}
      </p>

      <table className="data" style={{ marginTop: 20 }}>
        <thead>
          <tr>
            <th>Borrower</th>
            <th>Mobile</th>
            <th style={{ textAlign: "right" }}>Outstanding</th>
            <th>Loan due</th>
            <th>Predicted harvest</th>
            <th>Window confidence</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.farm_id}>
              <td>
                <Link href={link(`/farm/${r.farm_id}`)}>{r.borrower}</Link>
                <div className="note" style={{ fontSize: 11 }}>
                  <span className="mono">{r.farm_id}</span>
                </div>
              </td>
              {/* Masked at the API. A credit officer needs to know a number
                  exists and matches; nobody needs it rendered in full on a
                  screen that may be shared. */}
              <td className="mono" style={{ fontSize: 11 }}>{r.mobile_masked}</td>
              <td style={{ textAlign: "right" }}>{inr(r.outstanding_inr)}</td>
              <td>{shortDate(r.due_date)}</td>
              <td>
                {shortDate(r.predicted_harvest_date)}
                {r.due_before_harvest && (
                  <div style={{ fontSize: 11, color: "var(--risk)" }}>
                    loan matures before harvest
                  </div>
                )}
              </td>
              <td><StatePill state={r.harvest_confidence} /></td>
              <td>
                {r.action}
                {r.note && <div className="note" style={{ fontSize: 11, marginTop: 3 }}>
                  {r.note}</div>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default withParams(Calls);
