# drishti-frontend

DRISHTI+ — five screens over the live platform API. Next.js on Vercel.

## The one rule

**The client never formats a number.** Every metric arrives with a `display`
string already produced by the precision policy in the backend: a point value
when measured, a band when estimated, a range plus "last measured" when unseen.

A frontend that formats its own numbers can print `7.2` on a field nobody has
looked at in two months. That is the defect this product exists to remove, so it
is enforced at the boundary rather than by convention.

## Screens

| Route | What it answers |
|---|---|
| `/` | Book — who needs attention, ranked by exposure × days unseen |
| `/farm/[id]` | One field: the answer, the evidence, the method |
| `/calls` | Call list, ordered by when the crop is actually ready |
| `/coverage` | Blind days against SLA budget, and what escalation costs |
| `/evidence` | Append-only observation record |

The role switcher reorders the navigation. Jital's account of why the company
exists is that five people read the same dashboard about the same farm and each
misread it — a switcher that only changed a label would be decoration.

## Three things worth knowing before changing anything

**Blind renders as nothing.** Not grey, not a badge — the absence of ink on a
hairline baseline. A grey segment says "poor reading here"; nothing says "no
reading here". That distinction is the product.

**The hero is a sentence, not a number.** A large figure with a small label is
the default dashboard treatment and is exactly what makes the source product
read as a government form.

**The explanation panel shows its own working** — the answer, the evidence
chain, the five tools with the called ones marked, and whether a model wrote the
answer or the deterministic fallback did. That last state is a feature and is
displayed as one.

## Run

```bash
npm install
cp .env.example .env.local
npm run dev
```

## Deploy

```bash
vercel
vercel env add NEXT_PUBLIC_API   # https://elai-platform-production.up.railway.app
```

## Requires

`data/history.json` on the API side, written by `python -m app.cli history`.
Without it the season strips render as empty baselines and the page says so
rather than silently showing one season as if it were two years.

## Four roles, four first screens

The switcher changes **where you land**, not just what the tabs say.

| Role | Opens on | First question |
|---|---|---|
| Credit officer | `/` Book | who do I call this week |
| Field supervisor | `/map` | where do I go today |
| Claims assessor | `/timeline` | what happened, and when |
| Procurement | `/weeks` | how much, arriving when |

Same engine, same confidence states, same rule version. The facts do not vary
by role; only which of them are worth putting on a screen.

Two decisions worth preserving:

**The assessor sees no verdict.** No yield, no exposure, no conclusion — just
the dated record with the sensor and rule version behind each entry. An assessor
shown a conclusion has been led.

**Procurement commits against the floor, never the mid-point.** An exporter who
signs for the middle of a band is wrong half the time, and wrong in that
direction means defaulting on a shipment. A delivery week also inherits the
weakest state among its growers — one unseen field makes the whole week an
estimate, because that is what it is.
